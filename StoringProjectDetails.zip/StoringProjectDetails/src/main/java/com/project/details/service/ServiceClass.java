package com.project.details.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.details.entity.ProjectDetails;
import com.project.details.repository.RepositoryInterface;

@Service
public class ServiceClass {
	
	@Autowired
    RepositoryInterface repo;
	
	//add project details to database
	public String addProject(ProjectDetails projectdetails) {
		repo.save(projectdetails);
		return "ProjectDetails added successfully";
	}


	//view all projects data
	public List<ProjectDetails> viewAllProjectDetails() {
		return (List<ProjectDetails>) repo.findAll();
	}


	//view project details by id
	public Optional<ProjectDetails> viewProjectDetailsById(Integer id) {
		return repo.findById(id) ;
	}


	//update project details by id
	public String updateProjectDetails(ProjectDetails projectdetails, Integer id) {
		repo.updateUserDetails(projectdetails.getProjectName(), projectdetails.getStartDate(), projectdetails.getEndDate(), projectdetails.getProjectMngName(), projectdetails.getRequirement(), id);
		return "project details updated successfully";
	}

   
	//delete project details by id
	public String deleteProjectDetails(Integer id) {
		repo.deleteById(id);
		return "project details details deleted successfully";
	}
	
	

	
}
