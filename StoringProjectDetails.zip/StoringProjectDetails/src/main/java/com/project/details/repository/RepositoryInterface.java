package com.project.details.repository;

import java.sql.Date;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.project.details.entity.ProjectDetails;

@Repository
public interface RepositoryInterface extends CrudRepository<ProjectDetails,Integer>{
	
	@Query(nativeQuery = true, value = "update projectdetails set projectName = ?1, startDate = ?2, endDate = ?3 , projectMngName = ?4  ,requirement = ?5 where projectId = ?6")
	@Modifying
	@Transactional
	public void updateUserDetails(String name, Date startdate, Date enddate, String mngrname, String requirement, Integer id); 


}
