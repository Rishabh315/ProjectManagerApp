package com.project.details;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.details.entity.ProjectDetails;
import com.project.details.service.ServiceClass;

@RestController
@RequestMapping("/projectDetails")
public class ProjectDetailsController {

	@Autowired
	ServiceClass service;
	
	
	// add project details to database
	@PostMapping("/add")
	public String addProject(@RequestBody ProjectDetails projectdetails) {
		return service.addProject(projectdetails);
	}
	

	// view all projects data
	@RequestMapping("/viewAll")
	public List<ProjectDetails> viewAllProjectDetails() {
		return service.viewAllProjectDetails();
	}
	
	
	//view project details by id
	@RequestMapping("/viewbyid/{id}")
	public Optional<ProjectDetails> viewProjectDetailsById(@PathVariable Integer id) {
		return service.viewProjectDetailsById(id);
	}
	
	
	//update project details
	@PutMapping("/update/{id}")
	public String updateProjectDetails(@RequestBody ProjectDetails projectdetails,@PathVariable Integer id) {
		return service.updateProjectDetails(projectdetails,id);
	}
	
	
	//delete project details
	@DeleteMapping("/delete/{id}")
	public String deleteProjectDetails(@PathVariable Integer id) {
		return service.deleteProjectDetails(id);
	}
	
	
	

}
