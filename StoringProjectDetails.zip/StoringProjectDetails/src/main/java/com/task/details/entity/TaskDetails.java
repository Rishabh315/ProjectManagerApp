package com.task.details.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.project.details.entity.ProjectDetails;

@Entity
@Table(name="taskdetails")
public class TaskDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer taskId;
	
	
    @ManyToOne
    @JoinColumn(name = "projectId")
	private ProjectDetails projectdetails;
    
	
	private String tasks;
	public Integer getTaskId() {
		return taskId;
	}
	public void setTaskId(Integer taskId) {
		this.taskId = taskId;
	}
	
	public ProjectDetails getProjectdetails() {
		return projectdetails;
	}
	public void setProjectdetails(ProjectDetails projectdetails) {
		this.projectdetails = projectdetails;
	}
	public String getTasks() {
		return tasks;
	}
	public void setTasks(String tasks) {
		this.tasks = tasks;
	}

}
