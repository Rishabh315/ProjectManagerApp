package com.task.details.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.task.details.entity.TaskDetails;


@Repository
public interface RepositoryInterface extends CrudRepository<TaskDetails, Integer> {

}
