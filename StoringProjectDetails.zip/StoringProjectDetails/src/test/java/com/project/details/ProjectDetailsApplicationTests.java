package com.project.details;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
